<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      simplify your business
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2017 <a href="http://www.idekreasi.net">Ide Kreasi</a>.</strong> All rights reserved.
  </footer>