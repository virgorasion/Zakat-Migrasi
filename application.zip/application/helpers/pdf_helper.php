<?php

function tcpdf()
{
    require_once(APPPATH.'helpers/tcpdf/tcpdf.php');
}
?>