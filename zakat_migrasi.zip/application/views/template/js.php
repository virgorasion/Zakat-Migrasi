<!-- REQUIRED JS SCRIPTS -->
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/jQuery/jquery-2.2.3.min.js')?>"></script>
<!-- Jquery Confirm -->
<script src="<?php echo base_url('assets/jquery-confirm/jquery-confirm.min.js')?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/bootstrap/js/bootstrap.min.js')?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/datatables/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/datatables/dataTables.bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js'); ?>"></script>

<!-- bootstrap datepicker -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>

<script src="<?php echo base_url('assets/AdminLTE-2.3.7/dist/js/app.min.js')?>"></script>
<!-- JQuery Input Mask -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.7/plugins/inputmask/dist/jquery.inputmask.min.js')?>"></script>
<!-- Knockout -->
<script src="<?php echo base_url('assets/knockout/knockout-3.4.1.js')?>"></script>


<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. Slimscroll is required when using the
     fixed layout. -->
